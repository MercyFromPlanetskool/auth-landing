// AuthModal/AuthModal.jsx
// This file composes the full auth modal using modularized hooks, steps, and pieces.
// All UI classes and behaviour are preserved from the original LoginRegister.jsx.
// Comments from the original are retained/referenced where meaningful to keep intent.

import React from 'react';
import 'react-phone-number-input/style.css';
import '../styles/LoginRegister.css';

import useAuthFlow from '../hooks/useAuthFlow';
import useResponsiveOverlay from '../hooks/useResponsiveOverlay';

import SuccessDialog from './SuccessDialog';
import StepSignInEmail from './steps/StepSignInEmail';
import StepSignInPassword from './steps/StepSignInPassword';
import StepForgotPassword from './steps/StepForgotPassword';
import StepCreateNameUsername from './steps/StepCreateNameUsername';
import StepCreateBirthdayGender from './steps/StepCreateBirthdayGender';
import StepCreateContact from './steps/StepCreateContact';
import StepCreatePassword from './steps/StepCreatePassword';

const AuthModal = ({ isVisible, onClose }) => {
  const {
    currentFlow, currentStep, formData, errors,
    usernameAvailable, usernameSuggestions, isLoading,
    showSuccessDialog, successMessage,
    brandTitle, brandSubtitle,
    setField, handleInputChange, handleNext, handleBack, switchFlow, handleCloseSuccessDialog
  } = useAuthFlow(onClose);

  const {
    overlayRef, isMobile, isLandscape, viewportDimensions,
    handleTouchStart, handleTouchMove, handleTouchEnd,
    handleInputFocus, handleInputBlur
  } = useResponsiveOverlay(isVisible);

  // Small event bridge to allow "Sign in here" button in bday step to switch
  React.useEffect(() => {
    const handler = () => switchFlow('signin');
    window.addEventListener('auth:switch-signin', handler);
    return () => window.removeEventListener('auth:switch-signin', handler);
  }, [switchFlow]);

  const renderStep = () => {
    if (currentFlow === 'signin') {
      if (currentStep === 1) {
        return (
          <StepSignInEmail
            formData={formData}
            errors={errors}
            onChange={handleInputChange}
            onNext={handleNext}
            switchFlow={switchFlow}
            onFocus={handleInputFocus}
            onBlur={handleInputBlur}
          />
        );
      } else if (currentStep === 2) {
        return (
          <StepSignInPassword
            formData={formData}
            errors={errors}
            onChange={handleInputChange}
            onNext={handleNext}
            onBack={handleBack}
            switchFlow={switchFlow}
            onFocus={handleInputFocus}
            onBlur={handleInputBlur}
            isMobile={isMobile}
          />
        );
      }
    } else if (currentFlow === 'forgot') {
      return (
        <StepForgotPassword
          formData={formData}
          errors={errors}
          onChange={handleInputChange}
          onNext={handleNext}
          switchFlow={switchFlow}
        />
      );
    } else if (currentFlow === 'create') {
      if (currentStep === 1) {
        return (
          <StepCreateNameUsername
            formData={formData}
            errors={errors}
            onChange={handleInputChange}
            onNext={handleNext}
            switchFlow={switchFlow}
            usernameAvailable={usernameAvailable}
            usernameSuggestions={usernameSuggestions}
            isLoading={isLoading}
            setField={setField}
          />
        );
      } else if (currentStep === 2) {
        return (
          <StepCreateBirthdayGender
            formData={formData}
            errors={errors}
            onChange={handleInputChange}
            onNext={handleNext}
            onBack={handleBack}
            switchFlow={switchFlow}
          />
        );
      } else if (currentStep === 3) {
        return (
          <StepCreateContact
            formData={formData}
            errors={errors}
            onInputChange={handleInputChange}
            onPhoneChange={setField}
            onNext={handleNext}
            onBack={handleBack}
            onFocus={handleInputFocus}
            onBlur={handleInputBlur}
            switchFlow={switchFlow}
          />
        );
      } else if (currentStep === 4) {
        return (
          <StepCreatePassword
            formData={formData}
            errors={errors}
            onChange={handleInputChange}
            onNext={handleNext}
            onBack={handleBack}
            switchFlow={switchFlow}
          />
        );
      }
    }
    return null;
  };

  return (
    <div
      ref={overlayRef}
      className={`login-register-overlay ${isVisible ? 'visible' : ''} ${isMobile ? 'mobile' : 'desktop'} ${isLandscape ? 'landscape-mode' : 'portrait-mode'}`}
      data-flow={currentFlow}
      data-step={currentStep}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={(e) => handleTouchEnd(e, onClose)}
      style={{
        '--viewport-width': `${viewportDimensions.width}px`,
        '--viewport-height': `${viewportDimensions.height}px`
      }}
    >
      <div className="login-register-panel">
        <div className="auth-card">
          <div className="panel-header">
            <button
              className="back-btn"
              onClick={onClose}
              aria-label={isMobile ? "Close login" : "Back to main page"}
            >
              {isMobile ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              ) : (
                <>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  Back
                </>
              )}
            </button>
          </div>

          <div className="panel-content">
            <div className="brand-section">
              <h1 className="brand-title">{brandTitle}</h1>
              <p className="brand-subtitle">{brandSubtitle}</p>
            </div>

            <div className="form-container">
              {renderStep()}
            </div>
          </div>
        </div>
      </div>

      {showSuccessDialog && (
        <SuccessDialog message={successMessage} onClose={handleCloseSuccessDialog} />
      )}
    </div>
  );
};

export default AuthModal;
