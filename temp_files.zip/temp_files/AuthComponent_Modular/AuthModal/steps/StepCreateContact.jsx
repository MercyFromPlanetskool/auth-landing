// AuthModal/steps/StepCreateContact.jsx
import React from 'react';
import PhoneInput from 'react-phone-number-input';

const StepCreateContact = ({ formData, errors, onInputChange, onPhoneChange, onNext, onBack, onFocus, onBlur, switchFlow }) => {
  return (
    <div className="step-content">
      <div className="step-main-content">
        <div className="contact-section">
          <label className="section-label">Contact Information</label>

          <div className="form-group">
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={onInputChange}
              onFocus={onFocus}
              onBlur={onBlur}
              placeholder="Email address"
              className={`floating-input ${formData.email ? 'has-value' : ''} ${errors.email ? 'error' : ''}`}
              aria-label="Email address"
              autoComplete="email"
              inputMode="email"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck="false"
              required
            />
            <label className="floating-label">Email address</label>
            {errors.email && <span className="error-message" role="alert">{errors.email}</span>}
          </div>

          <div className="form-group">
            <div className="phone-input-container">
              <PhoneInput
                placeholder=""
                value={formData.phoneNumber}
                onChange={(value) => onPhoneChange('phoneNumber', value || '')}
                onFocus={onFocus}
                onBlur={onBlur}
                className={`phone-input ${formData.phoneNumber ? 'has-value' : ''} ${errors.phoneNumber ? 'error' : ''}`}
                countrySelectProps={{ 'aria-label': 'Country' }}
                numberInputProps={{
                  'aria-label': 'Phone number',
                  autoComplete: 'tel',
                  inputMode: 'tel',
                  autoCapitalize: 'none',
                  autoCorrect: 'off',
                  spellCheck: 'false'
                }}
                defaultCountry="IN"
                international
                countryCallingCodeEditable={true}
              />
              <label className={`floating-label ${formData.phoneNumber ? 'active' : ''}`}>
                Phone number
              </label>
            </div>
            {errors.phoneNumber && <span className="error-message" role="alert">{errors.phoneNumber}</span>}
          </div>

          {/*
            Under-18 parent contact UI (preserved as comment from original). To re-enable, add state flag and server flows.
            <div className="parent-contact-section">...</div>
          */}
        </div>
      </div>

      <div className="step-actions">
        <div className="step-buttons">
          <button type="button" className="secondary-button" onClick={onBack}>
            Back
          </button>
          <button type="button" className="primary-button" onClick={onNext}>
            Next
          </button>
        </div>

        <div className="alternative-actions">
          <span>Already have an account? </span>
          <button type="button" className="link-button" onClick={() => switchFlow('signin')}>
            Sign in here
          </button>
        </div>
      </div>
    </div>
  );
};

export default StepCreateContact;
