// AuthModal/steps/StepCreatePassword.jsx
import React from 'react';
import PasswordField from '../pieces/PasswordField';
import { getPasswordStrength } from '../../utils/validation';

const StepCreatePassword = ({ formData, errors, onChange, onNext, onBack, switchFlow }) => {
  return (
    <div className="step-content">
      <div className="step-main-content">
        <PasswordField
          name="password"
          label="Password"
          value={formData.password}
          onChange={onChange}
          error={errors.password}
          autoComplete="new-password"
          withStrength
          getPasswordStrength={getPasswordStrength}
        />

        <PasswordField
          name="confirmPassword"
          label="Confirm"
          value={formData.confirmPassword}
          onChange={onChange}
          error={errors.confirmPassword}
          autoComplete="new-password"
        />

        <div className="password-hint">
          Use 8 or more characters with a mix of letters, numbers & symbols
        </div>
      </div>

      <div className="step-actions">
        <div className="step-buttons">
          <button type="button" className="secondary-button" onClick={onBack}>
            Back
          </button>
          <button type="button" className="primary-button" onClick={onNext}>
            Create Account
          </button>
        </div>

        <div className="alternative-actions">
          <span>Already have an account? </span>
          <button type="button" className="link-button" onClick={() => switchFlow('signin')}>
            Sign in here
          </button>
        </div>
      </div>
    </div>
  );
};

export default StepCreatePassword;
