// AuthModal/steps/StepCreateBirthdayGender.jsx
import React, { useMemo } from 'react';

const StepCreateBirthdayGender = ({ formData, errors, onChange, onNext, onBack, switchFlow }) => {
  const months = useMemo(() => (['January','February','March','April','May','June','July','August','September','October','November','December']), []);

  const years = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const list = [];
    for (let y = currentYear - 100; y <= currentYear; y++) list.push(y);
    return list.reverse();
  }, []);

  return (
    <div className="step-content">
      <div className="step-main-content">
        <div className="birthday-section">
          <label className="section-label">Birthday</label>
          <div className="birthday-inputs">
            <select
              name="birthMonth"
              value={formData.birthMonth}
              onChange={onChange}
              className={`select-input ${errors.birthMonth ? 'error' : ''}`}
              aria-label="Birth month"
            >
              <option value="">Month</option>
              {months.map((m, idx) => <option key={idx} value={idx+1}>{m}</option>)}
            </select>

            <select
              name="birthDay"
              value={formData.birthDay}
              onChange={onChange}
              className={`select-input ${errors.birthDay ? 'error' : ''}`}
              aria-label="Birth day"
            >
              <option value="">Day</option>
              {Array.from({ length: 31 }, (_, i) => i + 1).map(d => <option key={d} value={d}>{d}</option>)}
            </select>

            <select
              name="birthYear"
              value={formData.birthYear}
              onChange={onChange}
              className={`select-input ${errors.birthYear ? 'error' : ''}`}
              aria-label="Birth year"
            >
              <option value="">Year</option>
              {years.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>

          {(errors.birthMonth || errors.birthDay || errors.birthYear) && (
            <div className="birthday-errors">
              {errors.birthMonth && <span className="error-message" role="alert">{errors.birthMonth}</span>}
              {errors.birthDay && <span className="error-message" role="alert">{errors.birthDay}</span>}
              {errors.birthYear && <span className="error-message" role="alert">{errors.birthYear}</span>}
            </div>
          )}
        </div>

        <div className="form-group">
          <select
            name="gender"
            value={formData.gender}
            onChange={onChange}
            className="select-input"
            aria-label="Gender"
          >
            <option value="">Select Gender</option>
            <option value="female">Female</option>
            <option value="male">Male</option>
            <option value="other">Other</option>
            <option value="prefer-not-to-say">Prefer not to say</option>
          </select>
        </div>
      </div>

      <div className="step-actions">
        <div className="step-buttons">
          <button type="button" className="secondary-button" onClick={onBack}>
            Back
          </button>
          <button type="button" className="primary-button" onClick={onNext}>
            Next
          </button>
        </div>

        <div className="alternative-actions">
          <span>Already have an account? </span>
          <button type="button" className="link-button" onClick={() => switchFlow('signin')}>
            Sign in here
          </button>
        </div>
      </div>
    </div>
  );
};

export default StepCreateBirthdayGender;
