// AuthModal/steps/StepSignInPassword.jsx
import React from 'react';
import PasswordField from '../pieces/PasswordField';

const StepSignInPassword = ({ formData, errors, onChange, onNext, onBack, switchFlow, onFocus, onBlur, isMobile }) => {
  return (
    <div className="step-content">
      <div className="step-main-content">
        <div className="step-header">
          <div className="user-info">
            <div className="user-avatar">
              {formData.email ? String(formData.email).charAt(0).toUpperCase() : ''}
            </div>
            <div className="user-details">
              <div className="user-email">{formData.email}</div>
            </div>
          </div>
        </div>

        <PasswordField
          name="password"
          label="Enter your password"
          value={formData.password}
          onChange={onChange}
          error={errors.password}
          autoComplete="current-password"
          onFocus={onFocus}
          onBlur={onBlur}
        />

        <div className="password-options">
          <button type="button" className="link-button forgot-password" onClick={() => switchFlow('forgot')}>
            Forgot password?
          </button>
        </div>
      </div>

      <div className="step-actions">
        <div className="step-buttons">
          <button type="button" className="secondary-button" onClick={onBack}>
            Back
          </button>
          <button type="button" className="primary-button" onClick={onNext}>
            Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default StepSignInPassword;
