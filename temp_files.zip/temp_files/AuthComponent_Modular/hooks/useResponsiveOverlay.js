// hooks/useResponsiveOverlay.js
// Extracted responsive overlay + mobile UX logic (orientation, swipe-to-close, VKB adjustments)
// from the original component. Apply the returned props/handlers to your overlay container.

import { useState, useEffect, useCallback, useRef } from 'react';

export const useResponsiveOverlay = (isVisible) => {
  const [isMobile, setIsMobile] = useState(false);
  const [isLandscape, setIsLandscape] = useState(false);
  const [viewportDimensions, setViewportDimensions] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 0,
    height: typeof window !== 'undefined' ? window.innerHeight : 0
  });

  const overlayRef = useRef(null);
  const activeInputRef = useRef(null);
  const resizeTimeoutRef = useRef(null);

  const updateViewport = useCallback(() => {
    const width = window.innerWidth;
    const height = window.innerHeight;

    setViewportDimensions({ width, height });
    setIsMobile(width <= 768);
    setIsLandscape(width > height);

    // Apply orientation-based CSS classes to overlay
    if (overlayRef.current) {
      const overlay = overlayRef.current;
      overlay.classList.remove('landscape-mode', 'portrait-mode');
      if (width > height) overlay.classList.add('landscape-mode');
      else overlay.classList.add('portrait-mode');
    }

    // Handle virtual keyboard on mobile
    if (width <= 768 && activeInputRef.current) {
      const viewportHeight = window.visualViewport?.height || height;
      if (viewportHeight < height * 0.75) {
        document.body.style.height = `${viewportHeight}px`;
      } else {
        document.body.style.height = '';
      }
    }
  }, []);

  useEffect(() => {
    updateViewport();

    const handleResize = () => {
      clearTimeout(resizeTimeoutRef.current);
      resizeTimeoutRef.current = setTimeout(updateViewport, 150);
    };

    const handleOrientationChange = () => {
      setTimeout(updateViewport, 300);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleOrientationChange);

    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', updateViewport);
    }

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleOrientationChange);
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', updateViewport);
      }
      document.body.style.height = '';
      clearTimeout(resizeTimeoutRef.current);
    };
  }, [updateViewport]);

  useEffect(() => {
    if (isVisible) {
      setTimeout(updateViewport, 50);
    }
  }, [isVisible, updateViewport]);

  const handleTouchStart = useCallback((e) => {
    if (!isMobile || !overlayRef.current) return;
    const touch = e.touches[0];
    overlayRef.current.touchStartX = touch.clientX;
    overlayRef.current.touchStartY = touch.clientY;
  }, [isMobile]);

  const handleTouchMove = useCallback((e) => {
    if (!isMobile || !overlayRef.current || !overlayRef.current.touchStartX) return;
    const touch = e.touches[0];
    const deltaX = touch.clientX - overlayRef.current.touchStartX;
    const deltaY = touch.clientY - overlayRef.current.touchStartY;

    if ((isLandscape && Math.abs(deltaX) > Math.abs(deltaY) && deltaX > 0) ||
        (!isLandscape && Math.abs(deltaY) > Math.abs(deltaX) && deltaY > 0)) {
      e.preventDefault();
    }
  }, [isMobile, isLandscape]);

  const handleTouchEnd = useCallback((e, onClose) => {
    if (!isMobile || !overlayRef.current || !overlayRef.current.touchStartX) return;
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - overlayRef.current.touchStartX;
    const deltaY = touch.clientY - overlayRef.current.touchStartY;
    const threshold = 50;

    if (isLandscape && deltaX > threshold) {
      onClose && onClose();
    } else if (!isLandscape && deltaY > threshold) {
      onClose && onClose();
    }

    overlayRef.current.touchStartX = null;
    overlayRef.current.touchStartY = null;
  }, [isMobile, isLandscape]);

  const handleInputFocus = useCallback((e) => {
    activeInputRef.current = e.target;
    if (isMobile) {
      setTimeout(() => {
        if (e.target && e.target.scrollIntoView) {
          e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 300);
    }
  }, [isMobile]);

  const handleInputBlur = useCallback(() => {
    if (isMobile) {
      setTimeout(() => {
        document.body.style.height = '';
      }, 300);
    }
  }, [isMobile]);

  return {
    overlayRef,
    isMobile,
    isLandscape,
    viewportDimensions,
    handleTouchStart,
    handleTouchMove,
    handleTouchEnd,
    handleInputFocus,
    handleInputBlur
  };
};

export default useResponsiveOverlay;
