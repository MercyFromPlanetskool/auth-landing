// hooks/useAuthFlow.js
// Centralized state & logic for the multi-step auth flow extracted from LoginRegister.jsx.
// Includes: flow/step control, form state, validation, username availability, and submission stubs.

import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { isValidPhoneNumber } from 'react-phone-number-input';
import {
  validateName, validateEmail, validatePhone, validateUsername,
  validateAge, validatePassword, getPasswordStrength
} from '../utils/validation';
import { sanitizeInput } from '../utils/sanitize';
import {
  cancelPending,
  checkUsernameAvailability as svcCheckUsernameAvailability,
  signIn as svcSignIn,
  register as svcRegister,
  sendPasswordReset as svcSendPasswordReset
} from '../services/authService';

const STORAGE_KEY = 'planetskool-registration-data';

export const INITIAL_FORM_DATA = {
  password: '',
  firstName: '',
  lastName: '',
  username: '',
  confirmPassword: '',
  phone: '',
  email: '',
  phoneNumber: '',
  recoveryEmail: '',
  birthDay: '',
  birthMonth: '',
  birthYear: '',
  gender: '',
  forgotEmail: '',
  // Parent contact information (preserved from original, currently unused while under-18 is disabled)
  parentFirstName: '',
  parentLastName: '',
  parentEmail: '',
  parentPhoneNumber: '',
  parentConsent: false
};

// Temporarily treat all users as 18+ to disable under-18 flows (preserves original logic)
// const isUserUnder18 = useMemo(...)
// For parity with the provided file we keep it constant:
const IS_USER_UNDER_18 = false;

export const useAuthFlow = (onClose) => {
  const [currentFlow, setCurrentFlow] = useState('signin'); // 'signin' | 'create' | 'forgot'
  const [currentStep, setCurrentStep] = useState(1);

  // Form data with session storage backup
  const [formData, setFormData] = useState(() => {
    try {
      const saved = typeof window !== 'undefined' ? window.sessionStorage.getItem(STORAGE_KEY) : null;
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...INITIAL_FORM_DATA, ...parsed, password: '', confirmPassword: '' };
      }
    } catch (_e) {}
    return { ...INITIAL_FORM_DATA };
  });

  // UI/UX state
  const [errors, setErrors] = useState({});
  const [usernameAvailable, setUsernameAvailable] = useState(null);
  const [usernameSuggestions, setUsernameSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Persist safe subset of formData in create flow
  useEffect(() => {
    if (currentFlow === 'create' && typeof window !== 'undefined') {
      try {
        const safeCopy = { ...formData };
        delete safeCopy.password;
        delete safeCopy.confirmPassword;
        window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(safeCopy));
      } catch (_e) {}
    }
  }, [formData, currentFlow]);

  // Cancel mocked async timers on unmount (username availability, etc.)
  useEffect(() => {
    return () => {
      cancelPending();
      clearTimeout(usernameCheckTimerRef.current);
    };
  }, []);

  const usernameCheckTimerRef = useRef(null);
  const activeUsernameReqId = useRef(0);

  const resetForm = useCallback(() => {
    setFormData({ ...INITIAL_FORM_DATA });
    setErrors({});
    setCurrentStep(1);
    setUsernameAvailable(null);
    setUsernameSuggestions([]);
    setShowSuccessDialog(false);
    setSuccessMessage('');
    if (typeof window !== 'undefined') {
      try { window.sessionStorage.removeItem(STORAGE_KEY); } catch (_e) {}
    }
  }, []);

  const switchFlow = useCallback((flow) => {
    setCurrentFlow(flow);
    resetForm();
  }, [resetForm]);

  // Encapsulated field setter for non-input controls (PhoneInput etc.)
  const setField = useCallback((name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
    // Real-time validation parity for phone
    if (name === 'phoneNumber' || name === 'parentPhoneNumber') {
      if (value && !isValidPhoneNumber(value)) {
        setErrors(prev => ({ ...prev, [name]: 'Please enter a valid phone number' }));
      } else {
        setErrors(prev => {
          const copy = { ...prev };
          delete copy[name];
          return copy;
        });
      }
    }
  }, [errors]);

  // Handle standard input change with sanitization + real-time validation
  const handleInputChange = useCallback((e) => {
    const { name, value } = e.target;

    // Sanitize based on field name
    let sanitizedValue = value;
    if (name === 'firstName' || name === 'lastName') {
      sanitizedValue = sanitizeInput(value, 'name');
    } else if (name === 'username') {
      sanitizedValue = sanitizeInput(value, 'username');
    } else if (name === 'email' || name === 'forgotEmail' || name === 'parentEmail' || name === 'recoveryEmail') {
      sanitizedValue = sanitizeInput(value, 'email');
    } else if (name === 'password' || name === 'confirmPassword') {
      sanitizedValue = sanitizeInput(value, 'password');
    }

    setFormData(prev => ({ ...prev, [name]: sanitizedValue }));

    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }

    const newErrors = { ...errors };

    switch (name) {
      case 'firstName': {
        if (value) {
          const err = validateName(value, 'First name');
          if (err) newErrors[name] = err; else delete newErrors[name];
        } else newErrors[name] = 'First name is required';
        break;
      }
      case 'lastName': {
        // Last name is optional — validate only when provided
        if (value && value.trim()) {
          const err = validateName(value, 'Last name');
          if (err) newErrors[name] = err; else delete newErrors[name];
        } else {
          // clear any previous error when field is empty
          delete newErrors[name];
        }
        break;
      }
      case 'email': {
        if (value && value.trim()) {
          if (!validateEmail(value.trim())) newErrors[name] = 'Please enter a valid email address';
          else delete newErrors[name];
        }
        break;
      }
      case 'forgotEmail': {
        if (value && value.trim()) {
          if (!validateEmail(value.trim())) newErrors[name] = 'Please enter a valid email address';
          else delete newErrors[name];
        }
        break;
      }
      case 'username': {
        if (value) {
          const uerr = validateUsername(value);
          if (uerr) newErrors[name] = uerr;
          else {
            delete newErrors[name];
            if (value.length > 2) {
              clearTimeout(usernameCheckTimerRef.current);
              usernameCheckTimerRef.current = setTimeout(async () => {
                setIsLoading(true);
                const reqId = ++activeUsernameReqId.current;
                const res = await svcCheckUsernameAvailability(value);
                if (reqId === activeUsernameReqId.current) {
                  setUsernameAvailable(res.available);
                  setUsernameSuggestions(res.suggestions || []);
                  setIsLoading(false);
                }
              }, 400);
            }
          }
        }
        break;
      }
      case 'password': {
        if (value) {
          const pv = validatePassword(value);
          if (!pv.isValid) newErrors[name] = pv.message; else delete newErrors[name];
          // Confirm password matching
          if (formData.confirmPassword && formData.confirmPassword !== value) {
            newErrors.confirmPassword = 'Passwords do not match';
          } else if (formData.confirmPassword && formData.confirmPassword === value) {
            delete newErrors.confirmPassword;
          }
        }
        break;
      }
      case 'confirmPassword': {
        if (value && formData.password) {
          if (value !== formData.password) newErrors[name] = 'Passwords do not match';
          else delete newErrors[name];
        }
        break;
      }
      case 'birthDay': {
        if (value) {
          const day = parseInt(value, 10);
          if (day < 1 || day > 31) {
            newErrors[name] = 'Please enter a valid day (1-31)';
          } else if (formData.birthMonth) {
            const year = formData.birthYear || 2000;
            const daysInMonth = new Date(year, formData.birthMonth, 0).getDate();
            if (day > daysInMonth) {
              newErrors[name] = `${new Date(year, formData.birthMonth - 1).toLocaleString('default', { month: 'long' })} has only ${daysInMonth} days`;
            } else delete newErrors[name];
          } else delete newErrors[name];
        }
        break;
      }
      case 'gender': {
        if (!value) newErrors[name] = 'Gender selection is required';
        else if (!['male', 'female', 'other', 'prefer-not-to-say'].includes(value)) newErrors[name] = 'Please select a valid gender option';
        else delete newErrors[name];
        break;
      }
      default:
        break;
    }

    setErrors(newErrors);
  }, [errors, formData.confirmPassword, formData.password]);

  // Step validation (parity with original)
  const validateCurrentStep = useCallback(() => {
    const newErrors = {};

    if (currentFlow === 'signin') {
      if (currentStep === 1) {
        if (!formData.email || !formData.email.trim()) {
          newErrors.email = 'Email address is required';
        } else if (!validateEmail(formData.email.trim())) {
          newErrors.email = 'Please enter a valid email address';
        }
      }
      // Step 2 (password) submit handled directly, no extra validation here
    } else if (currentFlow === 'forgot') {
      if (!formData.forgotEmail || !formData.forgotEmail.trim()) {
        newErrors.forgotEmail = 'Email address is required';
      } else if (!validateEmail(formData.forgotEmail.trim())) {
        newErrors.forgotEmail = 'Please enter a valid email address';
      }
    } else if (currentFlow === 'create') {
      if (currentStep === 1) {
        // Name + username
        const fnErr = validateName(formData.firstName, 'First name');
        if (fnErr) newErrors.firstName = fnErr;
        // Last name is optional — only validate if provided
        if (formData.lastName && formData.lastName.trim()) {
          const lnErr = validateName(formData.lastName, 'Last name');
          if (lnErr) newErrors.lastName = lnErr;
        }
        const unErr = validateUsername(formData.username);
        if (unErr) newErrors.username = unErr;
      } else if (currentStep === 2) {
        // Birthday + gender
        if (!formData.birthMonth) newErrors.birthMonth = 'Birth month is required';
        if (!formData.birthDay) newErrors.birthDay = 'Birth day is required';
        if (!formData.birthYear) newErrors.birthYear = 'Birth year is required';
        else {
          const currentYear = new Date().getFullYear();
          if (formData.birthYear < currentYear - 120 || formData.birthYear > currentYear) {
            newErrors.birthYear = 'Please enter a valid birth year';
          }
        }
        if (formData.birthYear && formData.birthMonth && formData.birthDay) {
          const ageError = validateAge(formData.birthYear, formData.birthMonth, formData.birthDay);
          if (ageError) newErrors.birthYear = ageError;
        }
        if (!formData.gender) newErrors.gender = 'Gender selection is required';
        else if (!['male', 'female', 'other', 'prefer-not-to-say'].includes(formData.gender)) {
          newErrors.gender = 'Please select a valid gender option';
        }
      } else if (currentStep === 3) {
        // Regular Contact Information validation (active)
        if (!formData.email) newErrors.email = 'Email address is required';
        else if (!validateEmail(formData.email)) newErrors.email = 'Please enter a valid email address';

        if (!formData.phoneNumber) newErrors.phoneNumber = 'Phone number is required';
        else if (!isValidPhoneNumber(formData.phoneNumber)) newErrors.phoneNumber = 'Please enter a valid phone number';

        /* Under-18 parent contact UI is commented out temporarily.
           To re-enable, uncomment and ensure parent verification flows server-side.

        if (IS_USER_UNDER_18) {
          if (!formData.parentFirstName) newErrors.parentFirstName = 'Parent\'s first name is required';
          else {
            const nerr = validateName(formData.parentFirstName, 'Parent\'s first name');
            if (nerr) newErrors.parentFirstName = nerr;
          }

          if (!formData.parentLastName) newErrors.parentLastName = 'Parent\'s last name is required';
          else {
            const nerr = validateName(formData.parentLastName, 'Parent\'s last name');
            if (nerr) newErrors.parentLastName = nerr;
          }

          if (!formData.parentEmail) newErrors.parentEmail = 'Parent\'s email address is required';
          else if (!validateEmail(formData.parentEmail)) newErrors.parentEmail = 'Please enter a valid email address';

          if (!formData.parentPhoneNumber) newErrors.parentPhoneNumber = 'Parent\'s phone number is required';
          else if (!isValidPhoneNumber(formData.parentPhoneNumber)) newErrors.parentPhoneNumber = 'Please enter a valid phone number';

          if (!formData.parentConsent) newErrors.parentConsent = 'Parent/guardian permission is required';
        }
        */
      } else if (currentStep === 4) {
        const pv = validatePassword(formData.password);
        if (!pv.isValid) newErrors.password = pv.message;

        if (!formData.confirmPassword) newErrors.confirmPassword = 'Please confirm your password';
        else if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';

        if (formData.password && formData.password.length >= 8) {
          let issues = [];
          if (!/[a-z]/.test(formData.password)) issues.push('lowercase letter');
          if (!/[A-Z]/.test(formData.password)) issues.push('uppercase letter');
          if (!/[0-9]/.test(formData.password)) issues.push('number');
          if (!/[!@#$%^&*(),.?":{}|<>]/.test(formData.password)) issues.push('special character');
          if (issues.length > 0) newErrors.password = `Password should include: ${issues.join(', ')}`;
        }
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [currentFlow, currentStep, formData]);

  const handleNext = useCallback(async () => {
    if (!validateCurrentStep()) return;

    if (currentFlow === 'signin' && currentStep === 2) {
      // Submit sign-in
      await svcSignIn({ email: formData.email, password: formData.password });
      onClose && onClose();
      return;
    }

    if (currentFlow === 'create' && currentStep === 4) {
      // Submit registration
      await svcRegister(formData);
      onClose && onClose();
      return;
    }

    if (currentFlow === 'forgot') {
      // Trigger forgot flow
      await svcSendPasswordReset({ email: formData.forgotEmail });
      setSuccessMessage(`Password reset link sent to ${formData.forgotEmail}`);
      setShowSuccessDialog(true);
      return;
    }

    // Step transitions (special case: create step 2 -> 3 even with under-18 logic disabled)
    if (currentFlow === 'create') {
      if (currentStep === 2) setCurrentStep(3);
      else setCurrentStep(prev => prev + 1);
    } else {
      setCurrentStep(prev => prev + 1);
    }
  }, [currentFlow, currentStep, formData, onClose, validateCurrentStep]);

  const handleBack = useCallback(() => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    } else if (currentFlow === 'create') {
      switchFlow('signin');
    }
  }, [currentStep, currentFlow, switchFlow]);

  const handleCloseSuccessDialog = useCallback(() => {
    setShowSuccessDialog(false);
    setSuccessMessage('');
    switchFlow('signin');
  }, [switchFlow]);

  // Helpers for UI:
  const brandTitle = currentFlow === 'signin' ? 'Sign in' : currentFlow === 'forgot' ? 'Forgot Password' : 'Create your account';
  const brandSubtitle = currentFlow === 'signin' ? 'Use your account to continue' : currentFlow === 'forgot' ? 'Reset your password easily' : 'Join Planetskool today';

  return {
    // state
    currentFlow,
    currentStep,
    formData,
    errors,
    usernameAvailable,
    usernameSuggestions,
    isLoading,
    showSuccessDialog,
    successMessage,

    // derived
    brandTitle,
    brandSubtitle,

    // actions
    setField,
    handleInputChange,
    handleNext,
    handleBack,
    switchFlow,
    handleCloseSuccessDialog
  };
};

export default useAuthFlow;
