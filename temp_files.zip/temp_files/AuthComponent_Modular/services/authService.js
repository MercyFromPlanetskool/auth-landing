// services/authService.js
// Mock/placeholder service layer with cancelable timeouts to mirror original behavior.
// Replace these with real API requests in production.

let activeTimers = new Set();

const withDelay = (result, ms = 500) => {
  return new Promise((resolve) => {
    const t = setTimeout(() => {
      activeTimers.delete(t);
      resolve(result);
    }, ms);
    activeTimers.add(t);
  });
};

export const cancelPending = () => {
  for (const t of activeTimers) clearTimeout(t);
  activeTimers.clear();
};

export const checkUsernameAvailability = async (username) => {
  const unavailable = ['admin', 'user', 'test', 'planetskool'];
  const available = !unavailable.includes(String(username).toLowerCase());

  const suggestions = available
    ? []
    : [`${username}123`, `${username}_ps`, `${username}2024`, `user_${username}`];

  return withDelay({ available, suggestions }, 500);
};

export const signIn = async ({ email, password }) => {
  // TODO: Replace with real sign-in logic
  return withDelay({ ok: true }, 400);
};

export const register = async (payload) => {
  // TODO: Replace with real registration logic
  return withDelay({ ok: true }, 600);
};

export const sendPasswordReset = async ({ email }) => {
  // TODO: Replace with real reset flow
  return withDelay({ ok: true }, 500);
};
