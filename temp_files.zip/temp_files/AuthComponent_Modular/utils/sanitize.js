// utils/sanitize.js
// NOTE: Preserves original intent & behaviour from LoginRegister.jsx
// Centralized sanitization used by hooks and steps.
export const sanitizeInput = (value, type = 'text') => {
  if (!value) return '';

  // Remove any potential script tags or malicious content
  const cleaned = value
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<[^>]*>?/gm, '')
    .trim();

  switch (type) {
    case 'name':
      return cleaned.replace(/[^a-zA-Z\s'-]/g, '').substring(0, 50);
    case 'username':
      return cleaned.replace(/[^a-zA-Z0-9._-]/g, '').substring(0, 30);
    case 'email':
      return cleaned.toLowerCase().substring(0, 254);
    case 'password':
      // Don't modify passwords, just validate them
      return value;
    default:
      return cleaned;
  }
};

export default sanitizeInput;
