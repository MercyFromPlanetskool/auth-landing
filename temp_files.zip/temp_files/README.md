# LandingPage Component

This is a React component conversion of the original HTML landing page with 3D Earth visualization using Three.js.

## Project Structure

```
src/
├── components/
│   └── LandingPage/
│       ├── LandingPage.jsx          # Main React component
│       ├── LandingPage.css          # Component styles
│       ├── index.js                 # Export file
│       └── utils/                   # Utility files
│           ├── index.js             # Utils export file
│           ├── config.js            # Configuration constants
│           ├── position.js          # Position management classes
│           ├── animation.js         # Animation manager
│           ├── fontLoader.js        # Font loading system
│           ├── utils.js             # Utility functions
│           └── earthScene.js        # 3D scene management
├── App.jsx                          # Main app component
├── App.css                          # App styles
├── index.css                        # Global styles
└── main.jsx                         # Entry point
```

## Features Preserved

✅ **All Original Features Maintained:**
- Interactive 3D Earth with realistic textures
- Cloud layer with transparency
- Starfield background
- Real-time sun positioning and lighting
- Lens flare effects
- Responsive design for all screen sizes
- Smooth animations and transitions
- "Get Started" button with glass morphism effect
- Text positioning that follows Earth center
- User interaction detection
- Orbital controls with damping
- Dynamic font loading
- Mobile-optimized touch controls

## Usage

```jsx
import LandingPage from './components/LandingPage';

function App() {
  return <LandingPage />;
}
```

## Dependencies

- **React** - Component framework
- **Three.js** - 3D graphics library
- **Vite** - Build tool and dev server

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## File Breakdown

### Main Component
- **LandingPage.jsx**: React wrapper that initializes the 3D scene and manages lifecycle

### Utility Files
- **config.js**: All configuration constants (camera settings, animation speeds, URLs)
- **position.js**: Position management and calculation classes
- **animation.js**: Smooth animation and lerping functionality
- **fontLoader.js**: Custom font loading with fallbacks
- **utils.js**: Responsive design calculations and utility functions
- **earthScene.js**: Complete Three.js scene management (Earth, clouds, stars, lighting)

### Styling
- **LandingPage.css**: Component-specific styles matching original HTML exactly
- **index.css**: Global styles and resets
- **App.css**: Minimal app-level styles

## Notes

- All original JavaScript functionality has been preserved
- No features have been lost in the conversion
- The component is fully self-contained
- Three.js is imported as ES modules (not CDN scripts)
- Responsive design works across all device sizes
- Performance optimizations are maintained

## File Count
**Total Files Created: 8**
- 1 Main component file (LandingPage.jsx)
- 1 CSS file (LandingPage.css)
- 2 Index files (component and utils exports)
- 6 Utility JavaScript files
