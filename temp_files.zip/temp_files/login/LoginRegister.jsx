import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import PhoneInput, { isValidPhoneNumber } from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import './LoginRegister.css';

// Central initial form data to avoid duplication and accidental divergence
const INITIAL_FORM_DATA = {
  password: '',
  firstName: '',
  lastName: '',
  username: '',
  confirmPassword: '',
  phone: '',
  email: '',
  phoneNumber: '',
  recoveryEmail: '',
  birthDay: '',
  birthMonth: '',
  birthYear: '',
  gender: '',
  forgotEmail: '',
  // Parent contact information
  parentFirstName: '',
  parentLastName: '',
  parentEmail: '',
  parentPhoneNumber: '',
  parentConsent: false
};

const LoginRegister = ({ isVisible, onClose }) => {
  // Main flow state
  const [currentFlow, setCurrentFlow] = useState('signin'); // 'signin', 'create', or 'forgot'
  const [currentStep, setCurrentStep] = useState(1);

  // Responsive state
  const [isMobile, setIsMobile] = useState(false);
  const [isLandscape, setIsLandscape] = useState(false);
  const [viewportDimensions, setViewportDimensions] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 0,
    height: typeof window !== 'undefined' ? window.innerHeight : 0
  });

  // Refs for better mobile UX
  const overlayRef = useRef(null);
  const panelRef = useRef(null);
  const activeInputRef = useRef(null);

  // Form data with session storage backup
  const [formData, setFormData] = useState(() => {
    // Try to restore limited, non-sensitive fields from session storage on mount
    try {
      const savedData = sessionStorage.getItem('planetskool-registration-data');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        // Ensure sensitive fields are not restored from storage
        return {
          ...INITIAL_FORM_DATA,
          ...parsed,
          password: '',
          confirmPassword: ''
        };
      }
      return { ...INITIAL_FORM_DATA };
    } catch (error) {
      return { ...INITIAL_FORM_DATA };
    }
  });

  // Save form data to session storage whenever it changes
  // Persist a sanitized subset of formData (exclude sensitive fields)
  useEffect(() => {
    if (currentFlow === 'create') {
      try {
        const safeCopy = { ...formData };
        // Remove sensitive fields before persisting
        delete safeCopy.password;
        delete safeCopy.confirmPassword;
        sessionStorage.setItem('planetskool-registration-data', JSON.stringify(safeCopy));
      } catch (error) {
        // Could not save form data to session storage
      }
    }
  }, [formData, currentFlow]);

  // UI state
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [usernameAvailable, setUsernameAvailable] = useState(null);
  const [usernameSuggestions, setUsernameSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Responsive viewport detection with orientation-based CSS classes
  const updateViewport = useCallback(() => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    
    setViewportDimensions({ width, height });
    setIsMobile(width <= 768);
    setIsLandscape(width > height);
    
    // Apply orientation-based CSS classes to overlay
    if (overlayRef.current) {
      const overlay = overlayRef.current;
      
      // Remove existing orientation classes
      overlay.classList.remove('landscape-mode', 'portrait-mode');
      
      // Add appropriate orientation class based on screen dimensions
      if (width > height) {
        // Landscape: slide from right
        overlay.classList.add('landscape-mode');
      } else {
        // Portrait: slide from bottom
        overlay.classList.add('portrait-mode');
      }
    }
    
    // Handle virtual keyboard on mobile
    if (width <= 768 && activeInputRef.current) {
      const viewportHeight = window.visualViewport?.height || height;
      if (viewportHeight < height * 0.75) {
        // Virtual keyboard is likely open
        document.body.style.height = `${viewportHeight}px`;
      } else {
        document.body.style.height = '';
      }
    }
  }, []);

  // Responsive effects
  const resizeTimeoutRef = useRef(null);

  useEffect(() => {
    updateViewport();
    
    const handleResize = () => {
      // Debounce resize events
      clearTimeout(resizeTimeoutRef.current);
      resizeTimeoutRef.current = setTimeout(updateViewport, 150);
    };
    
    const handleOrientationChange = () => {
      // Handle orientation change with a slight delay
      setTimeout(updateViewport, 300);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleOrientationChange);
    
    // Visual Viewport API support for mobile browsers
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', updateViewport);
    }

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleOrientationChange);
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', updateViewport);
      }
      document.body.style.height = '';
      clearTimeout(resizeTimeoutRef.current);
    };
  }, [updateViewport]);

  // Clean up username check timers/requests on unmount
  useEffect(() => {
    return () => {
      clearTimeout(usernameCheckTimerRef.current);
      if (activeUsernameRequestRef.current) clearTimeout(activeUsernameRequestRef.current);
    };
  }, []);

  // Update orientation classes when component becomes visible
  useEffect(() => {
    if (isVisible) {
      // Small delay to ensure DOM is ready
      setTimeout(updateViewport, 50);
    }
  }, [isVisible, updateViewport]);

  // Reset form when flow changes (but preserve data when just going back steps)
  const resetForm = () => {
    const initialFormData = {
      password: '',
      firstName: '',
      lastName: '',
      username: '',
      confirmPassword: '',
      phone: '',
      email: '', // New separate email field
      phoneNumber: '', // New separate phone field
      recoveryEmail: '',
      birthDay: '',
      birthMonth: '',
      birthYear: '',
      gender: '',
      forgotEmail: ''
    };
    
    setFormData(initialFormData);
    setErrors({});
    setCurrentStep(1);
    setUsernameAvailable(null);
    setUsernameSuggestions([]);
    setShowPassword(false);
    setShowSuccessDialog(false);
    setSuccessMessage('');
    
    // Clear session storage when resetting form
    try {
      sessionStorage.removeItem('planetskool-registration-data');
    } catch (error) {
      // Could not clear session storage
    }
  };

  // Switch between flows
  const switchFlow = (flow) => {
    setCurrentFlow(flow);
    resetForm();
  };

  // Enhanced input sanitization and security
  const sanitizeInput = (value, type = 'text') => {
    if (!value) return '';
    
    // Remove any potential script tags or malicious content
    const cleaned = value
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<[^>]*>?/gm, '')
      .trim();
    
    switch (type) {
      case 'name':
        return cleaned.replace(/[^a-zA-Z\s'-]/g, '').substring(0, 50);
      case 'username':
        return cleaned.replace(/[^a-zA-Z0-9._-]/g, '').substring(0, 30);
      case 'email':
        return cleaned.toLowerCase().substring(0, 254);
      case 'password':
        return value; // Don't modify passwords, just validate them
      default:
        return cleaned;
    }
  };

  // Input change handler with enhanced security and validation
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    activeInputRef.current = e.target;
    
    // Sanitize input based on field type
    let sanitizedValue = value;
    if (name === 'firstName' || name === 'lastName') {
      sanitizedValue = sanitizeInput(value, 'name');
    } else if (name === 'username') {
      sanitizedValue = sanitizeInput(value, 'username');
  } else if (name === 'email' || name === 'forgotEmail') {
      sanitizedValue = sanitizeInput(value, 'email');
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: sanitizedValue
    }));
    
    // Clear existing error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }

    // Real-time validation for specific fields
    const newErrors = { ...errors };
    
    switch (name) {
      case 'firstName':
        if (value) {
          const nameError = validateName(value, 'First name');
          if (nameError) newErrors[name] = nameError;
          else delete newErrors[name];
        } else {
          newErrors[name] = 'First name is required';
        }
        break;
        
      case 'lastName':
        // Last name is now required
        if (!value || !value.trim()) {
          newErrors[name] = 'Last name is required';
        } else {
          const nameError = validateName(value, 'Last name');
          if (nameError) newErrors[name] = nameError;
          else delete newErrors[name];
        }
        break;
        
      case 'email':
        if (value && value.trim()) {
          if (!validateEmail(value.trim())) {
            newErrors[name] = 'Please enter a valid email address';
          } else {
            delete newErrors[name];
          }
        }
        break;

      case 'phoneNumber':
        // For react-phone-number-input, we don't need real-time validation
        // as it handles format validation internally
        if (value && !isValidPhoneNumber(value)) {
          newErrors[name] = 'Please enter a valid phone number';
        } else {
          delete newErrors[name];
        }
        break;
        
      case 'forgotEmail':
        if (value && value.trim()) {
          if (!validateEmail(value.trim())) {
            newErrors[name] = 'Please enter a valid email address';
          } else {
            delete newErrors[name];
          }
        }
        break;
        
      case 'username':
        if (value) {
          const usernameError = validateUsername(value);
          if (usernameError) {
            newErrors[name] = usernameError;
          } else {
            delete newErrors[name];
            // Check availability for valid usernames
            if (value.length > 2) {
              // debounce availability checks
              clearTimeout(usernameCheckTimerRef.current);
              usernameCheckTimerRef.current = setTimeout(() => {
                checkUsernameAvailability(value);
              }, 400);
            }
          }
        }
        break;
        
      case 'password':
        if (value) {
          const passwordValidation = validatePassword(value);
          if (!passwordValidation.isValid) {
            newErrors[name] = passwordValidation.message;
          } else {
            delete newErrors[name];
          }
          
          // Also check confirm password if it exists
          if (formData.confirmPassword && formData.confirmPassword !== value) {
            newErrors.confirmPassword = 'Passwords do not match';
          } else if (formData.confirmPassword && formData.confirmPassword === value) {
            delete newErrors.confirmPassword;
          }
        }
        break;
        
      case 'confirmPassword':
        if (value && formData.password) {
          if (value !== formData.password) {
            newErrors[name] = 'Passwords do not match';
          } else {
            delete newErrors[name];
          }
        }
        break;
        
      case 'birthDay':
        if (value) {
          const day = parseInt(value);
          if (day < 1 || day > 31) {
            newErrors[name] = 'Please enter a valid day (1-31)';
          } else if (formData.birthMonth) {
            const year = formData.birthYear || 2000;
            const daysInMonth = new Date(year, formData.birthMonth, 0).getDate();
            if (day > daysInMonth) {
              newErrors[name] = `${new Date(year, formData.birthMonth - 1).toLocaleString('default', { month: 'long' })} has only ${daysInMonth} days`;
            } else {
              delete newErrors[name];
            }
          } else {
            delete newErrors[name];
          }
        }
        break;
        
      case 'gender':
        if (!value) {
          newErrors[name] = 'Gender selection is required';
        } else if (!['male', 'female', 'other', 'prefer-not-to-say'].includes(value)) {
          newErrors[name] = 'Please select a valid gender option';
        } else {
          delete newErrors[name];
        }
        break;
        
      default:
        break;
    }
    
    setErrors(newErrors);
  };

  // Username availability simulation
  const usernameCheckTimerRef = useRef(null);
  const activeUsernameRequestRef = useRef(null);

  const checkUsernameAvailability = async (username) => {
    setIsLoading(true);
    // Cancel any simulated previous request (for parity with real API cancellation)
    if (activeUsernameRequestRef.current) {
      clearTimeout(activeUsernameRequestRef.current);
      activeUsernameRequestRef.current = null;
    }

    // Simulate API call with cancelable timeout
    activeUsernameRequestRef.current = setTimeout(() => {
      const unavailable = ['admin', 'user', 'test', 'planetskool'];
      const isAvailable = !unavailable.includes(username.toLowerCase());
      setUsernameAvailable(isAvailable);

      if (!isAvailable) {
        setUsernameSuggestions([
          `${username}123`,
          `${username}_ps`,
          `${username}2024`,
          `user_${username}`
        ]);
      } else {
        setUsernameSuggestions([]);
      }
      setIsLoading(false);
      activeUsernameRequestRef.current = null;
    }, 500);
  };

  // Password validation function
  const validatePassword = (password) => {
    if (!password) return { isValid: false, message: 'Password is required' };
    if (password.length < 8) return { isValid: false, message: 'Password must be at least 8 characters long' };
    if (password.length > 128) return { isValid: false, message: 'Password must be less than 128 characters' };
    
    // Check for at least one of each required character type
    const hasLower = /[a-z]/.test(password);
    const hasUpper = /[A-Z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    const missingTypes = [];
    if (!hasLower) missingTypes.push('lowercase letter');
    if (!hasUpper) missingTypes.push('uppercase letter');
    if (!hasNumber) missingTypes.push('number');
    if (!hasSpecial) missingTypes.push('special character');
    
    // At least 3 of 4 character types required for security
    const typeCount = [hasLower, hasUpper, hasNumber, hasSpecial].filter(Boolean).length;
    if (typeCount < 3) {
      return { 
        isValid: false, 
        message: `Password must include at least 3 of: ${missingTypes.join(', ')}` 
      };
    }
    
    // Check for common weak patterns
    const weakPatterns = [
      /(.)\1{2,}/,  // Three or more consecutive identical characters
      /123|abc|qwe/i, // Common sequences
      /password|123456|qwerty/i // Common weak passwords
    ];
    
    if (weakPatterns.some(pattern => pattern.test(password))) {
      return { 
        isValid: false, 
        message: 'Password contains common patterns. Please choose a stronger password.' 
      };
    }
    
    return { isValid: true, message: 'Password is strong' };
  };

  // Check if user is under 18
  /*
  const isUserUnder18 = useMemo(() => {
    if (!formData.birthYear || !formData.birthMonth || !formData.birthDay) return false;
    
    const today = new Date();
    const birthDate = new Date(formData.birthYear, formData.birthMonth - 1, formData.birthDay);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age < 18;
  }, [formData.birthYear, formData.birthMonth, formData.birthDay]);
  */

  // Temporarily treat all users as 18+ to disable under-18 flows (preserves original logic above)
  const isUserUnder18 = false;

  // Memoized validation functions for better performance
  const validationFunctions = useMemo(() => ({
    validateName: (name, fieldName, isOptional = false) => {
      if (!name || !name.trim()) {
        return isOptional ? '' : `${fieldName} is required`;
      }
      if (name.trim().length < 2) return `${fieldName} must be at least 2 characters`;
      if (name.trim().length > 50) return `${fieldName} must be less than 50 characters`;
      if (!/^[a-zA-Z\s'-]+$/.test(name.trim())) return `${fieldName} can only contain letters, spaces, hyphens and apostrophes`;
      return '';
    },
    
    validateEmail: (email) => {
      if (!email || !email.trim()) return false;
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email.trim());
    },
    
    validatePhone: (phone) => {
      if (!phone || !phone.trim()) return false;
      const phoneRegex = /^[\+]?[\d\s\-\(\)]{10,}$/;
      const cleanPhone = phone.replace(/\D/g, '');
      return phoneRegex.test(phone) && cleanPhone.length >= 10 && cleanPhone.length <= 15;
    },
    
    validateUsername: (username) => {
      if (!username || !username.trim()) return 'Username is required';
      if (username.length < 3) return 'Username must be at least 3 characters';
      if (username.length > 30) return 'Username must be less than 30 characters';
      if (!/^[a-zA-Z0-9._-]+$/.test(username)) return 'Username can only contain letters, numbers, dots, underscores and hyphens';
      if (username.startsWith('.') || username.endsWith('.')) return 'Username cannot start or end with a dot';
      if (username.includes('..')) return 'Username cannot contain consecutive dots';
      return '';
    },
    
    validateAge: (birthYear, birthMonth, birthDay) => {
      if (!birthYear || !birthMonth || !birthDay) return 'Complete date of birth is required';
      
      const today = new Date();
      const birthDate = new Date(birthYear, birthMonth - 1, birthDay);
      
      if (birthDate > today) return 'Date of birth cannot be in the future';
      if (birthDate.getFullYear() < today.getFullYear() - 120) return 'Please enter a valid birth date';
      
      return '';
    }
  }), []);

  // Extract validation functions for easier use
  const { validateName, validateEmail, validatePhone, validateUsername, validateAge } = validationFunctions;

  const getPasswordStrength = (password) => {
    if (!password) return { strength: 0, text: '', class: '' };
    
    let strength = 0;
    const checks = {
      length: password.length >= 8,
      lowercase: /[a-z]/.test(password),
      uppercase: /[A-Z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
    };
    
    strength = Object.values(checks).filter(Boolean).length;
    
    if (strength <= 2) {
      return { strength, text: 'Weak', class: 'weak' };
    } else if (strength === 3) {
      return { strength, text: 'Fair', class: 'fair' };
    } else if (strength === 4) {
      return { strength, text: 'Good', class: 'good' };
    } else {
      return { strength, text: 'Strong', class: 'strong' };
    }
  };

  // Step validation
  const validateCurrentStep = () => {
    const newErrors = {};

    if (currentFlow === 'signin') {
      if (currentStep === 1) {
        if (!formData.email || !formData.email.trim()) {
          newErrors.email = 'Email address is required';
        } else if (!validateEmail(formData.email.trim())) {
          newErrors.email = 'Please enter a valid email address';
        }
      } else if (currentStep === 3 && isUserUnder18) {
        /*
        Under-18 parent contact UI is commented out temporarily.
        To re-enable, uncomment this block and ensure parent verification flows are implemented server-side.

        return (
          <div className="step-content">
            <div className="step-main-content">
              <div className="parent-contact-section">
                <div className="info-note parent-info">
                  <p>Since you're under 18, we need your parent or guardian's contact information.</p>
                  <p>They will receive a verification email to approve your account.</p>
                </div>

                <label className="section-label">Parent/Guardian Information</label>
                
                <div className="form-row">
                  <div className="form-group">
                    <input
                      type="text"
                      name="parentFirstName"
                      value={formData.parentFirstName}
                      onChange={handleInputChange}
                      placeholder="Parent's first name"
                      className={`floating-input ${formData.parentFirstName ? 'has-value' : ''} ${errors.parentFirstName ? 'error' : ''}`}
                      aria-label="Parent's first name"
                    />
                    <label className="floating-label">Parent's first name</label>
                    {errors.parentFirstName && <span className="error-message" role="alert">{errors.parentFirstName}</span>}
                  </div>

                  <div className="form-group">
                    <input
                      type="text"
                      name="parentLastName"
                      value={formData.parentLastName}
                      onChange={handleInputChange}
                      placeholder="Parent's last name"
                      className={`floating-input ${formData.parentLastName ? 'has-value' : ''} ${errors.parentLastName ? 'error' : ''}`}
                      aria-label="Parent's last name"
                    />
                    <label className="floating-label">Parent's last name</label>
                    {errors.parentLastName && <span className="error-message" role="alert">{errors.parentLastName}</span>}
                  </div>
                </div>

                <div className="form-group">
                  <input
                    type="email"
                    name="parentEmail"
                    value={formData.parentEmail}
                    onChange={handleInputChange}
                    placeholder="Parent's email address"
                    className={`floating-input ${formData.parentEmail ? 'has-value' : ''} ${errors.parentEmail ? 'error' : ''}`}
                    aria-label="Parent's email address"
                  />
          newErrors.birthYear = 'Birth year is required';
        } else {
          const currentYear = new Date().getFullYear();
          if (formData.birthYear < currentYear - 120 || formData.birthYear > currentYear) {
            newErrors.birthYear = 'Please enter a valid birth year';
          }
        }

        // Age validation (only if all date fields are filled)
        if (formData.birthYear && formData.birthMonth && formData.birthDay) {
          const ageError = validateAge(formData.birthYear, formData.birthMonth, formData.birthDay);
          if (ageError) {
            newErrors.birthYear = ageError;
          }
        }

        // Gender validation (now required)
        if (!formData.gender) {
          newErrors.gender = 'Gender selection is required';
        } else if (!['male', 'female', 'other', 'prefer-not-to-say'].includes(formData.gender)) {
          newErrors.gender = 'Please select a valid gender option';
        }

      } else if (currentStep === 3) {
        /*
        // Under-18 validation (commented out temporarily)
        if (isUserUnder18) {
          // Parent Contact Information validation
          if (!formData.parentFirstName) {
            newErrors.parentFirstName = 'Parent\'s first name is required';
          } else {
            const nameError = validateName(formData.parentFirstName, 'Parent\'s first name');
            if (nameError) newErrors.parentFirstName = nameError;
          }

          if (!formData.parentLastName) {
            newErrors.parentLastName = 'Parent\'s last name is required';
          } else {
            const nameError = validateName(formData.parentLastName, 'Parent\'s last name');
            if (nameError) newErrors.parentLastName = nameError;
          }

          if (!formData.parentEmail) {
            newErrors.parentEmail = 'Parent\'s email address is required';
          } else if (!validateEmail(formData.parentEmail)) {
            newErrors.parentEmail = 'Please enter a valid email address';
          }

          if (!formData.parentPhoneNumber) {
            newErrors.parentPhoneNumber = 'Parent\'s phone number is required';
          } else if (!isValidPhoneNumber(formData.parentPhoneNumber)) {
            newErrors.parentPhoneNumber = 'Please enter a valid phone number';
          }

          if (!formData.parentConsent) {
            newErrors.parentConsent = 'Parent/guardian permission is required';
          }
        } else {
          // Regular Contact Information validation
          if (!formData.email) {
            newErrors.email = 'Email address is required';
          } else if (!validateEmail(formData.email)) {
            newErrors.email = 'Please enter a valid email address';
          }

          if (!formData.phoneNumber) {
            newErrors.phoneNumber = 'Phone number is required';
          } else if (!isValidPhoneNumber(formData.phoneNumber)) {
            newErrors.phoneNumber = 'Please enter a valid phone number';
          }
        }
        */

        // Regular Contact Information validation (active)
        if (!formData.email) {
          newErrors.email = 'Email address is required';
        } else if (!validateEmail(formData.email)) {
          newErrors.email = 'Please enter a valid email address';
        }

        if (!formData.phoneNumber) {
          newErrors.phoneNumber = 'Phone number is required';
        } else if (!isValidPhoneNumber(formData.phoneNumber)) {
          newErrors.phoneNumber = 'Please enter a valid phone number';
        }

      } else if (currentStep === 4) {
        // Password validation
        const passwordValidation = validatePassword(formData.password);
        if (!passwordValidation.isValid) {
          newErrors.password = passwordValidation.message;
        }

        // Confirm password validation
        if (!formData.confirmPassword) {
          newErrors.confirmPassword = 'Please confirm your password';
        } else if (formData.password !== formData.confirmPassword) {
          newErrors.confirmPassword = 'Passwords do not match';
        }

        // Additional password strength checks
        if (formData.password && formData.password.length >= 8) {
          let strengthIssues = [];
          if (!/[a-z]/.test(formData.password)) strengthIssues.push('lowercase letter');
          if (!/[A-Z]/.test(formData.password)) strengthIssues.push('uppercase letter');
          if (!/[0-9]/.test(formData.password)) strengthIssues.push('number');
          if (!/[!@#$%^&*(),.?":{}|<>]/.test(formData.password)) strengthIssues.push('special character');
          
          if (strengthIssues.length > 0) {
            newErrors.password = `Password should include: ${strengthIssues.join(', ')}`;
          }
        }
      }
    } else if (currentFlow === 'forgot') {
      // Forgot password validation
      if (!formData.forgotEmail || !formData.forgotEmail.trim()) {
        newErrors.forgotEmail = 'Email address is required';
      } else if (!validateEmail(formData.forgotEmail.trim())) {
        newErrors.forgotEmail = 'Please enter a valid email address';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Navigation handlers
  const handleNext = () => {
    if (validateCurrentStep()) {
      if (currentFlow === 'signin' && currentStep === 2) {
        handleSubmit();
      } else if (currentFlow === 'create' && currentStep === 4) {
        handleSubmit();
      } else if (currentFlow === 'forgot') {
        handleForgotPasswordSubmit();
      } else {
        // For create flow, handle step transitions properly
        if (currentFlow === 'create') {
          if (currentStep === 2) {
            // After DOB step, always go to contact information step (step 3)
            setCurrentStep(3);
          } else {
            // For other steps, just increment normally
            setCurrentStep(prev => prev + 1);
          }
        } else {
          setCurrentStep(prev => prev + 1);
        }
      }
    }
  };

  // Enhanced handleBack that preserves form data
  const handleBack = () => {
    if (currentStep > 1) {
      // Standard back navigation - just go back one step
      setCurrentStep(prev => prev - 1);
      // Clear any errors from the current step but preserve form data
      setErrors(prev => {
        const newErrors = { ...prev };
        // Only clear errors that are not relevant to previous steps
        return newErrors;
      });
    } else if (currentFlow === 'create') {
      // If on step 1 of registration, go back to signin
      switchFlow('signin');
    }
  };

  const handleSubmit = () => {
    // Handle actual submission here
    onClose();
  };

  const handleForgotPasswordSubmit = () => {
    // Handle forgot password submission here
    setSuccessMessage(`Password reset link sent to ${formData.forgotEmail}`);
    setShowSuccessDialog(true);
  };

  const handleCloseSuccessDialog = () => {
    setShowSuccessDialog(false);
    setSuccessMessage('');
    switchFlow('signin'); // Return to signin after closing dialog
  };

  // Handle ESC key and mobile back button
  useEffect(() => {
    const handleEscapeKey = (event) => {
      if (event.key === 'Escape') {
        if (showSuccessDialog) {
          handleCloseSuccessDialog();
        } else if (isVisible) {
          onClose();
        }
      }
    };

    const handleBackButton = (event) => {
      if (isVisible && isMobile) {
        event.preventDefault();
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscapeKey);
    
    // Handle mobile back button
    if (isMobile && 'history' in window) {
      window.addEventListener('popstate', handleBackButton);
      if (isVisible) {
        window.history.pushState(null, '', window.location.href);
      }
    }

    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
      if (isMobile) {
        window.removeEventListener('popstate', handleBackButton);
      }
    };
  }, [showSuccessDialog, isVisible, isMobile, onClose]);

  // Touch handling for mobile swipe gestures
  const handleTouchStart = useCallback((e) => {
    if (!isMobile || !overlayRef.current) return;
    
    const touch = e.touches[0];
    overlayRef.current.touchStartX = touch.clientX;
    overlayRef.current.touchStartY = touch.clientY;
  }, [isMobile]);

  const handleTouchMove = useCallback((e) => {
    if (!isMobile || !overlayRef.current || !overlayRef.current.touchStartX) return;
    
    const touch = e.touches[0];
    const deltaX = touch.clientX - overlayRef.current.touchStartX;
    const deltaY = touch.clientY - overlayRef.current.touchStartY;
    
    // Prevent scrolling when swiping to close
    if ((isLandscape && Math.abs(deltaX) > Math.abs(deltaY) && deltaX > 0) ||
        (!isLandscape && Math.abs(deltaY) > Math.abs(deltaX) && deltaY > 0)) {
      e.preventDefault();
    }
  }, [isMobile, isLandscape]);

  const handleTouchEnd = useCallback((e) => {
    if (!isMobile || !overlayRef.current || !overlayRef.current.touchStartX) return;
    
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - overlayRef.current.touchStartX;
    const deltaY = touch.clientY - overlayRef.current.touchStartY;
    
    const threshold = 50; // Minimum swipe distance
    
    // Close on swipe in the appropriate direction
    if (isLandscape && deltaX > threshold) {
      onClose(); // Swipe right in landscape
    } else if (!isLandscape && deltaY > threshold) {
      onClose(); // Swipe down in portrait
    }
    
    // Clean up
    overlayRef.current.touchStartX = null;
    overlayRef.current.touchStartY = null;
  }, [isMobile, isLandscape, onClose]);

  // Focus management for mobile
  const handleInputFocus = useCallback((e) => {
    activeInputRef.current = e.target;
    
    if (isMobile) {
      // Scroll input into view on mobile
      setTimeout(() => {
        if (e.target && e.target.scrollIntoView) {
          e.target.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'center' 
          });
        }
      }, 300); // Wait for virtual keyboard
    }
  }, [isMobile]);

  const handleInputBlur = useCallback(() => {
    if (isMobile) {
      // Reset body height when input loses focus
      setTimeout(() => {
        document.body.style.height = '';
      }, 300);
    }
  }, [isMobile]);

  // Generate years for birthday
  const generateYears = () => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let year = currentYear - 100; year <= currentYear; year++) {
      years.push(year);
    }
    return years.reverse();
  };

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Render different steps based on current flow and step
  const renderCurrentStep = () => {
    if (currentFlow === 'signin') {
      if (currentStep === 1) {
        return (
          <div className="step-content">
            <div className="step-main-content">
              <div className="social-auth-section">
                <button type="button" className="google-button" onClick={() => {}}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  </svg>
                  Continue with Google
                </button>
                
                <div className="divider">
                  <span>or</span>
                </div>
              </div>

              <div className="form-group">
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  onFocus={handleInputFocus}
                  onBlur={handleInputBlur}
                  placeholder="you@example.com"
                  className={`floating-input ${formData.email ? 'has-value' : ''} ${errors.email ? 'error' : ''}`}
                  aria-label="Email address"
                  autoComplete="email"
                  inputMode={isMobile ? "email" : undefined}
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck="false"
                />
                <label className="floating-label">Email address</label>
                {errors.email && <span className="error-message" role="alert">{errors.email}</span>}
              </div>
            </div>
            
            <div className="step-actions">
              <div className="step-buttons">
                <button type="button" className="primary-button" onClick={handleNext}>
                  Next
                </button>
              </div>
              
              <div className="alternative-actions">
                <span>Don't have an account? </span>
                <button type="button" className="link-button" onClick={() => switchFlow('create')}>
                  Sign up here
                </button>
              </div>
            </div>
          </div>
        );
      } else if (currentStep === 2) {
        return (
          <div className="step-content">
            <div className="step-main-content">
              <div className="step-header">
                <div className="user-info">
                  <div className="user-avatar">
                    {formData.email ? formData.email.charAt(0).toUpperCase() : ''}
                  </div>
                  <div className="user-details">
                    <div className="user-email">{formData.email}</div>
                  </div>
                </div>
              </div>

              <div className="form-group">
                <div className="password-input-container">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    onFocus={handleInputFocus}
                    onBlur={handleInputBlur}
                    placeholder="Enter your password"
                    className={`floating-input ${formData.password ? 'has-value' : ''} ${errors.password ? 'error' : ''}`}
                    aria-label="Password"
                    autoComplete="current-password"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck="false"
                  />
                  <label className="floating-label">Enter your password</label>
                  <button
                    type="button"
                    className="password-toggle-btn"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    ) : (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </button>
                </div>
                {errors.password && <span className="error-message" role="alert">{errors.password}</span>}
              </div>

              <div className="password-options">
                <button type="button" className="link-button forgot-password" onClick={() => switchFlow('forgot')}>
                  Forgot password?
                </button>
              </div>
            </div>

            <div className="step-actions">
              <div className="step-buttons">
                <button type="button" className="secondary-button" onClick={handleBack}>
                  Back
                </button>
                <button type="button" className="primary-button" onClick={handleNext}>
                  Login
                </button>
              </div>
            </div>
          </div>
        );
      }
    } else if (currentFlow === 'forgot') {
      return (
        <div className="step-content">
          <div className="step-main-content">
            <div className="forgot-header">
              <h3>Reset your password</h3>
              <p>Enter your email address and we'll send you a link to reset your password.</p>
            </div>
            
            <div className="form-group">
              <input
                type="email"
                name="forgotEmail"
                value={formData.forgotEmail}
                onChange={handleInputChange}
                placeholder="Enter your email address"
                className={`floating-input ${formData.forgotEmail ? 'has-value' : ''} ${errors.forgotEmail ? 'error' : ''}`}
                aria-label="Email address"
                autoComplete="email"
              />
              <label className="floating-label">Enter your email address</label>
              {errors.forgotEmail && <span className="error-message" role="alert">{errors.forgotEmail}</span>}
            </div>
          </div>

          <div className="step-actions">
            <div className="step-buttons">
              <button type="button" className="secondary-button" onClick={() => switchFlow('signin')}>
                Back to Sign in
              </button>
              <button type="button" className="primary-button" onClick={handleNext}>
                Send Reset Link
              </button>
            </div>
          </div>

          <div className="alternative-actions">
            <span>Don't have an account? </span>
            <button type="button" className="link-button" onClick={() => switchFlow('create')}>
              Sign up here
            </button>
          </div>
        </div>
      );
    } else if (currentFlow === 'create') {
      if (currentStep === 1) {
        return (
          <div className="step-content">
            <div className="step-main-content">
              <div className="social-auth-section">
                <button type="button" className="google-button" onClick={() => {}}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  </svg>
                  Continue with Google
                </button>
                
                <div className="divider">
                  <span>or</span>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    placeholder="First name"
                    className={`floating-input ${formData.firstName ? 'has-value' : ''} ${errors.firstName ? 'error' : ''}`}
                    aria-label="First name"
                    autoComplete="given-name"
                  />
                  <label className="floating-label">First name</label>
                  {errors.firstName && <span className="error-message" role="alert">{errors.firstName}</span>}
                </div>

                <div className="form-group">
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    placeholder="Last name"
                    className={`floating-input ${formData.lastName ? 'has-value' : ''} ${errors.lastName ? 'error' : ''}`}
                    aria-label="Last name"
                    autoComplete="family-name"
                  />
                  <label className="floating-label">Last name</label>
                  {errors.lastName && <span className="error-message" role="alert">{errors.lastName}</span>}
                </div>
              </div>

              <div className="form-group">
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  placeholder="Username"
                  className={`floating-input ${formData.username ? 'has-value' : ''} ${errors.username ? 'error' : ''}`}
                  aria-label="Username"
                  autoComplete="username"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck="false"
                />
                <label className="floating-label">Username</label>
                {isLoading && <span className="loading-indicator">Checking availability...</span>}
                {usernameAvailable === true && <span className="success-message">✓ Username is available</span>}
                {errors.username && <span className="error-message" role="alert">{errors.username}</span>}
              </div>

              {usernameSuggestions.length > 0 && (
                <div className="suggestions">
                  <p className="suggestions-label">Try these instead:</p>
                  <div className="suggestion-pills">
                    {usernameSuggestions.map((suggestion, index) => (
                      <button
                        key={index}
                        type="button"
                        className="suggestion-pill"
                        onClick={() => setFormData(prev => ({ ...prev, username: suggestion }))}
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="step-actions">
              <div className="step-buttons">
                <button type="button" className="primary-button" onClick={handleNext}>
                  Next
                </button>
              </div>
              
              <div className="alternative-actions">
                <span>Already have an account? </span>
                <button type="button" className="link-button" onClick={() => switchFlow('signin')}>
                  Sign in here
                </button>
              </div>
            </div>
          </div>
        );
      } else if (currentStep === 2) {
        return (
          <div className="step-content">
            <div className="step-main-content">
              <div className="birthday-section">
                <label className="section-label">Birthday</label>
                <div className="birthday-inputs">
                  <select
                    name="birthMonth"
                    value={formData.birthMonth}
                    onChange={handleInputChange}
                    className={`select-input ${errors.birthMonth ? 'error' : ''}`}
                    aria-label="Birth month"
                  >
                    <option value="">Month</option>
                    {months.map((month, index) => (
                      <option key={index} value={index + 1}>{month}</option>
                    ))}
                  </select>

                  <select
                    name="birthDay"
                    value={formData.birthDay}
                    onChange={handleInputChange}
                    className={`select-input ${errors.birthDay ? 'error' : ''}`}
                    aria-label="Birth day"
                  >
                    <option value="">Day</option>
                    {Array.from({ length: 31 }, (_, i) => i + 1).map(day => (
                      <option key={day} value={day}>{day}</option>
                    ))}
                  </select>

                  <select
                    name="birthYear"
                    value={formData.birthYear}
                    onChange={handleInputChange}
                    className={`select-input ${errors.birthYear ? 'error' : ''}`}
                    aria-label="Birth year"
                  >
                    <option value="">Year</option>
                    {generateYears().map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </div>
                {(errors.birthMonth || errors.birthDay || errors.birthYear) && (
                  <div className="birthday-errors">
                    {errors.birthMonth && <span className="error-message" role="alert">{errors.birthMonth}</span>}
                    {errors.birthDay && <span className="error-message" role="alert">{errors.birthDay}</span>}
                    {errors.birthYear && <span className="error-message" role="alert">{errors.birthYear}</span>}
                  </div>
                )}
              </div>

              <div className="form-group">
                <select
                  name="gender"
                  value={formData.gender}
                  onChange={handleInputChange}
                  className="select-input"
                  aria-label="Gender"
                >
                  <option value="">Select Gender</option>
                  <option value="female">Female</option>
                  <option value="male">Male</option>
                  <option value="other">Other</option>
                  <option value="prefer-not-to-say">Prefer not to say</option>
                </select>
              </div>
            </div>

            <div className="step-actions">
              <div className="step-buttons">
                <button type="button" className="secondary-button" onClick={handleBack}>
                  Back
                </button>
                <button type="button" className="primary-button" onClick={handleNext}>
                  Next
                </button>
              </div>
              
              <div className="alternative-actions">
                <span>Already have an account? </span>
                <button type="button" className="link-button" onClick={() => switchFlow('signin')}>
                  Sign in here
                </button>
              </div>
            </div>
          </div>
        );
      } else if (currentStep === 3 && isUserUnder18) {
        return (
          <div className="step-content">
            <div className="step-main-content">
              <div className="parent-contact-section">
                <div className="info-note parent-info">
                  <p>Since you're under 18, we need your parent or guardian's contact information.</p>
                  <p>They will receive a verification email to approve your account.</p>
                </div>

                <label className="section-label">Parent/Guardian Information</label>
                
                <div className="form-row">
                  <div className="form-group">
                    <input
                      type="text"
                      name="parentFirstName"
                      value={formData.parentFirstName}
                      onChange={handleInputChange}
                      placeholder="Parent's first name"
                      className={`floating-input ${formData.parentFirstName ? 'has-value' : ''} ${errors.parentFirstName ? 'error' : ''}`}
                      aria-label="Parent's first name"
                    />
                    <label className="floating-label">Parent's first name</label>
                    {errors.parentFirstName && <span className="error-message" role="alert">{errors.parentFirstName}</span>}
                  </div>

                  <div className="form-group">
                    <input
                      type="text"
                      name="parentLastName"
                      value={formData.parentLastName}
                      onChange={handleInputChange}
                      placeholder="Parent's last name"
                      className={`floating-input ${formData.parentLastName ? 'has-value' : ''} ${errors.parentLastName ? 'error' : ''}`}
                      aria-label="Parent's last name"
                    />
                    <label className="floating-label">Parent's last name</label>
                    {errors.parentLastName && <span className="error-message" role="alert">{errors.parentLastName}</span>}
                  </div>
                </div>

                <div className="form-group">
                  <input
                    type="email"
                    name="parentEmail"
                    value={formData.parentEmail}
                    onChange={handleInputChange}
                    placeholder="Parent's email address"
                    className={`floating-input ${formData.parentEmail ? 'has-value' : ''} ${errors.parentEmail ? 'error' : ''}`}
                    aria-label="Parent's email address"
                  />
                  <label className="floating-label">Parent's email address</label>
                  {errors.parentEmail && <span className="error-message" role="alert">{errors.parentEmail}</span>}
                </div>

                <div className="form-group">
                  <div className="phone-input-container">
                    <PhoneInput
                      placeholder=""
                      value={formData.parentPhoneNumber}
                      onChange={(value) => setFormData(prev => ({ ...prev, parentPhoneNumber: value || '' }))}
                      className={`phone-input ${formData.parentPhoneNumber ? 'has-value' : ''} ${errors.parentPhoneNumber ? 'error' : ''}`}
                      countrySelectProps={{ 'aria-label': 'Parent\'s phone country' }}
                      numberInputProps={{
                        'aria-label': 'Parent\'s phone number',
                        placeholder: 'Parent\'s phone number'
                      }}
                      defaultCountry="IN"
                      international
                      countryCallingCodeEditable={true}
                    />
                    <label className={`floating-label ${formData.parentPhoneNumber ? 'active' : ''}`}>
                      Parent's phone number
                    </label>
                  </div>
                  {errors.parentPhoneNumber && <span className="error-message" role="alert">{errors.parentPhoneNumber}</span>}
                </div>

                <div className="form-options">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={formData.parentConsent}
                      onChange={(e) => setFormData(prev => ({ ...prev, parentConsent: e.target.checked }))}
                    />
                    <span className="checkmark"></span>
                    I confirm that I have my parent/guardian's permission
                  </label>
                  {errors.parentConsent && <span className="error-message" role="alert">{errors.parentConsent}</span>}
                </div>
              </div>
            </div>

            <div className="step-actions">
              <div className="step-buttons">
                <button type="button" className="secondary-button" onClick={handleBack}>
                  Back
                </button>
                <button type="button" className="primary-button" onClick={handleNext}>
                  Next
                </button>
              </div>
            </div>
          </div>
        );
      } else if (currentStep === 3) {
        return (
          <div className="step-content">
            <div className="step-main-content">
              <div className="contact-section">
                <label className="section-label">Contact Information</label>
                
                <div className="form-group">
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    onFocus={handleInputFocus}
                    onBlur={handleInputBlur}
                    placeholder="Email address"
                    className={`floating-input ${formData.email ? 'has-value' : ''} ${errors.email ? 'error' : ''}`}
                    aria-label="Email address"
                    autoComplete="email"
                    inputMode={isMobile ? "email" : undefined}
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck="false"
                    required
                  />
                  <label className="floating-label">Email address</label>
                  {errors.email && <span className="error-message" role="alert">{errors.email}</span>}
                </div>

                <div className="form-group">
                  <div className="phone-input-container">
                    <PhoneInput
                      placeholder=""
                      value={formData.phoneNumber}
                      onChange={(value) => setFormData(prev => ({ ...prev, phoneNumber: value || '' }))}
                      onFocus={handleInputFocus}
                      onBlur={handleInputBlur}
                      className={`phone-input ${formData.phoneNumber ? 'has-value' : ''} ${errors.phoneNumber ? 'error' : ''}`}
                      countrySelectProps={{
                        'aria-label': 'Country'
                      }}
                      numberInputProps={{
                        'aria-label': 'Phone number',
                        autoComplete: 'tel',
                        inputMode: isMobile ? "tel" : undefined,
                        autoCapitalize: "none",
                        autoCorrect: "off",
                        spellCheck: "false"
                      }}
                      defaultCountry="IN"
                      international
                      countryCallingCodeEditable={true}
                    />
                    <label className={`floating-label ${formData.phoneNumber ? 'active' : ''}`}>
                      Phone number
                    </label>
                  </div>
                  {errors.phoneNumber && <span className="error-message" role="alert">{errors.phoneNumber}</span>}
                </div>
              </div>
            </div>

            <div className="step-actions">
              <div className="step-buttons">
                <button type="button" className="secondary-button" onClick={handleBack}>
                  Back
                </button>
                <button type="button" className="primary-button" onClick={handleNext}>
                  Next
                </button>
              </div>
              
              <div className="alternative-actions">
                <span>Already have an account? </span>
                <button type="button" className="link-button" onClick={() => switchFlow('signin')}>
                  Sign in here
                </button>
              </div>
            </div>
          </div>
        );
      } else if (currentStep === 4) {
        return (
          <div className="step-content">
            <div className="step-main-content">
              <div className="form-group">
                <div className="password-input-container">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    onFocus={handleInputFocus}
                    onBlur={handleInputBlur}
                    placeholder="Password"
                    className={`floating-input ${formData.password ? 'has-value' : ''} ${errors.password ? 'error' : ''}`}
                    aria-label="Password"
                    autoComplete="new-password"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck="false"
                  />
                  <label className="floating-label">Password</label>
                  <button
                    type="button"
                    className="password-toggle-btn"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    ) : (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </button>
                </div>
                {errors.password && <span className="error-message" role="alert">{errors.password}</span>}
                
                {/* Password Strength Indicator */}
                {formData.password && (
                  <div className="password-strength">
                    <div className="strength-bar">
                      <div className={`strength-fill ${getPasswordStrength(formData.password).class}`}></div>
                    </div>
                    <span className={`strength-text ${getPasswordStrength(formData.password).class}`}>
                      {getPasswordStrength(formData.password).text}
                    </span>
                  </div>
                )}
              </div>

              <div className="form-group">
                <div className="password-input-container">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    placeholder="Confirm"
                    className={`floating-input ${formData.confirmPassword ? 'has-value' : ''} ${errors.confirmPassword ? 'error' : ''}`}
                    aria-label="Confirm password"
                    autoComplete="new-password"
                  />
                  <label className="floating-label">Confirm</label>
                  <button
                    type="button"
                    className="password-toggle-btn"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    ) : (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </button>
                </div>
                {errors.confirmPassword && <span className="error-message" role="alert">{errors.confirmPassword}</span>}
              </div>

              <div className="password-hint">
                Use 8 or more characters with a mix of letters, numbers & symbols
              </div>
            </div>

            <div className="step-actions">
              <div className="step-buttons">
                <button type="button" className="secondary-button" onClick={handleBack}>
                  Back
                </button>
                <button type="button" className="primary-button" onClick={handleNext}>
                  Create Account
                </button>
              </div>
              
              <div className="alternative-actions">
                <span>Already have an account? </span>
                <button type="button" className="link-button" onClick={() => switchFlow('signin')}>
                  Sign in here
                </button>
              </div>
            </div>
          </div>
        );
      }
    }

    return null;
  };

  return (
    <div 
      ref={overlayRef}
      className={`login-register-overlay ${isVisible ? 'visible' : ''} ${isMobile ? 'mobile' : 'desktop'} ${isLandscape ? 'landscape-mode' : 'portrait-mode'}`}
      data-flow={currentFlow}
      data-step={currentStep}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{
        '--viewport-width': `${viewportDimensions.width}px`,
        '--viewport-height': `${viewportDimensions.height}px`
      }}
    >
      <div ref={panelRef} className="login-register-panel">
        <div className="auth-card">
          <div className="panel-header">
            <button 
              className="back-btn" 
              onClick={onClose} 
              aria-label={isMobile ? "Close login" : "Back to main page"}
            >
              {isMobile ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              ) : (
                <>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  Back
                </>
              )}
            </button>
          </div>
          
          <div className="panel-content">
            <div className="brand-section">
              <h1 className="brand-title">
                {currentFlow === 'signin' ? 'Sign in' : currentFlow === 'forgot' ? 'Forgot Password' : 'Create your account'}
              </h1>
              <p className="brand-subtitle">
                {currentFlow === 'signin' ? 'Use your account to continue' : currentFlow === 'forgot' ? 'Reset your password easily' : 'Join Planetskool today'}
              </p>
            </div>

            <div className="form-container">
              {renderCurrentStep()}
            </div>
          </div>
        </div>
      </div>
      
      {/* Success Dialog */}
      {showSuccessDialog && (
        <div className="dialog-overlay" onClick={handleCloseSuccessDialog}>
          <div className="dialog-content" onClick={(e) => e.stopPropagation()}>
            <div className="dialog-header">
              <div className="dialog-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="10" fill="#10b981"/>
                  <path d="m9 12 2 2 4-4" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3>Email Sent!</h3>
            </div>
            <div className="dialog-body">
              <p>{successMessage}</p>
              <p className="dialog-subtitle">Please check your email and follow the instructions to reset your password.</p>
            </div>
            <div className="dialog-actions">
              <button type="button" className="primary-button" onClick={handleCloseSuccessDialog}>
                Back to Sign In
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginRegister;
